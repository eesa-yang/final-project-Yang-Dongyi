# 导入Flask类
from flask import request, Flask
from flask import render_template
import json
import pymysql

app = Flask(__name__)
# 这个注意比较坑  jinja 和vue模板语法冲突 必须要修改一下不能用插值表达式
app.jinja_env.variable_start_string = '{['
app.jinja_env.variable_end_string = ']}'


@app.route('/')
def index1():
    return render_template('index.html')


# route()方法用于设定路由；类似spring路由配置
@app.route('/index')
def index():
    return render_template('index.html')


def query_shop_list(num):
    cur = connect()
    sql = "select  * from shop order by rand() limit " + str(num)
    cur.execute(sql)
    result = cur.fetchall()
    shopList = []
    for item in result:
        shop = {'id': item[0], 'name': item[1], 'address': item[2], 'img_url': item[3], 'price': item[4],
                'message': item[5]}
        shopList.append(shop)
    return shopList


def connect():
    db = pymysql.connect(host="47.99.40.195", user="root", password="root", database="shop-map",
                         charset="utf8")
    cur = db.cursor()
    return cur


def query_shop_detail(id):
    cur = connect()
    sql = "select  * from shop where id= " + str(id)
    cur.execute(sql)
    result = cur.fetchall()
    shopList = []
    for item in result:
        shop = {'id': item[0], 'name': item[1], 'address': item[2], 'img_url': item[3], 'price': item[4],
                'message': item[5]}
        shopList.append(shop)
    return shopList


def add_comment():
    pass


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        params = request.get_data()
        req = json.loads(params.decode())
        db = pymysql.connect(host="47.99.40.195", user="root", password="root", database="shop-map",
                             charset="utf8")
        cur = db.cursor()
        sql = '''
        select  * from user where mobile='{}'
        '''.format(req['mobile'])
        cur.execute(sql)
        db.commit()
        user = cur.fetchall()
        if user is None:
            result = {
                "status": -1,
                "msg": "该用户未注册哦",
                "list": None
            }
            return result
        else:
            resp = {}
            for item in user:
                resp['nickname'] = item[1]
            result = {
                "status": 200,
                "msg": "成功",
                "data": resp
            }
            return result
    else:
        return render_template('login.html')

    return render_template('login.html')


@app.route('/shopDetail')
def shop_detail():
    id = request.args.get("id")
    print("id=" + id)
    shop_list = query_shop_detail(id)
    print(shop_list)
    return render_template('shop-detail.html', item=shop_list[0])


def register_user(name, password, mobile):
    cur = connect()
    sql = '''
    INSERT INTO user(nickname, password, avatar, gender, mobile, status) VALUES
    ('{}', '{}', 'https://testimg.imlianka.com/image/dgdsd.jpg', 1, '{}', 1)
    
    '''.format(name, password, mobile)
    print(sql)
    cur.execute(sql)


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        params = request.get_data()
        req = json.loads(params.decode())
        db = pymysql.connect(host="47.99.40.195", user="root", password="root", database="shop-map",
                             charset="utf8")
        cur = db.cursor()
        sql = '''
        INSERT INTO user(nickname, password, avatar, gender, mobile, status) VALUES
        ('{}', '{}', 'https://testimg.imlianka.com/image/dgdsd.jpg', 1, '{}', 1)

        '''.format(req['nickname'], req['password'], req['mobile'])
        cur.execute(sql)
        db.commit()
        result = {
            "status": 200,
            "msg": "成功",
            "list": None
        }
        return result
    else:
        return render_template('register.html')


@app.route('/shopList')
def shop_list():
    shopList = query_shop_list(10)
    result = {
        "status": 200,
        "msg": "成功",
        "list": shopList
    }
    return result


@app.route('/hotList')
def hot_list():
    shopList = query_shop_list(3)
    result = {
        "status": 200,
        "msg": "成功",
        "list": shopList
    }
    return result


if __name__ == '__main__':
    app.run('localhost', 5000)
