from flask import Flask



from flaskshop.flaskshop import app
